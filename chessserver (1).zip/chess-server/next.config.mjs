/** @type {import('next').NextConfig} */
const nextConfig = {
  // CORS is handled in middleware.ts so the browser game (GAME_ORIGIN) can
  // call the /api/* endpoints. Nothing else to configure — this deploys to
  // Vercel with zero extra setup.
};

export default nextConfig;
