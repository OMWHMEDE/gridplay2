// ===========================================================================
// SHOP ITEMS  ——  EDIT THIS LIST TO CHANGE WHAT PLAYERS CAN BUY WITH COINS
// ===========================================================================
//
// These are things a player unlocks by SPENDING coins (board themes, piece
// sets, etc.). The PRICE LIVES HERE ON THE SERVER ONLY. The browser game never
// sends a price or an amount to deduct — it only sends the item's id, and the
// server looks up the real price here. This prevents players from cheating the
// price.
//
// Each item needs a unique "id" (used by the game and stored in the database),
// a human "name", and a "price" in coins.
// ===========================================================================

export interface ShopItem {
  id: string;
  name: string;
  price: number; // in coins
}

export const SHOP_ITEMS: ShopItem[] = [
  // Board themes
  { id: "theme_classic_wood", name: "Classic Wood Board", price: 500 },
  { id: "theme_midnight_blue", name: "Midnight Blue Board", price: 1000 },
  { id: "theme_emerald", name: "Emerald Board", price: 1500 },
  { id: "theme_neon", name: "Neon Board", price: 3000 },

  // Piece sets
  { id: "pieces_marble", name: "Marble Piece Set", price: 800 },
  { id: "pieces_gold", name: "Gold Piece Set", price: 2000 },
  { id: "pieces_dragon", name: "Dragon Piece Set", price: 3000 },
];

const ITEMS_BY_ID = new Map(SHOP_ITEMS.map((item) => [item.id, item]));

/** Look up a shop item by id, or `undefined` if it doesn't exist. */
export function getShopItem(id: string): ShopItem | undefined {
  return ITEMS_BY_ID.get(id);
}
