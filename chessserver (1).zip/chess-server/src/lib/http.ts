import { NextRequest, NextResponse } from "next/server";
import { SESSION_COOKIE, verifySessionToken } from "./session";
import { env } from "./env";

// ---------------------------------------------------------------------------
// Small helpers shared by the API routes.
// ---------------------------------------------------------------------------

/** JSON response helper. */
export function json(data: unknown, status = 200): NextResponse {
  return NextResponse.json(data, { status });
}

/**
 * Identify the logged-in player from their session cookie.
 * Returns the Whop user id, or null if not logged in. The player's identity
 * ALWAYS comes from here — never from the request body or query string.
 */
export function getPlayerId(req: NextRequest): string | null {
  const token = req.cookies.get(SESSION_COOKIE)?.value;
  return verifySessionToken(token);
}

/**
 * Work out this server's public base URL (e.g. https://my-server.vercel.app)
 * so we can build the OAuth redirect URL. Uses PUBLIC_URL if set, otherwise
 * derives it from the incoming request (which is correct on Vercel).
 */
export function getBaseUrl(req: NextRequest): string {
  if (env.PUBLIC_URL) return env.PUBLIC_URL.replace(/\/$/, "");
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
  const proto = req.headers.get("x-forwarded-proto") ?? "https";
  return `${proto}://${host}`;
}

/** The absolute OAuth callback URL that must be registered in Whop. */
export function getRedirectUri(req: NextRequest): string {
  return `${getBaseUrl(req)}/api/auth/callback`;
}
