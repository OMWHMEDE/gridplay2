import { neon } from "@neondatabase/serverless";
import { env } from "./env";

// ---------------------------------------------------------------------------
// Database (Neon Postgres)
//
// All coin math happens inside single, atomic SQL statements. We NEVER read a
// balance into JavaScript, change it, and write it back — that would corrupt
// balances if two requests ran at the same time. Instead the database does the
// add/subtract itself, which is safe under concurrency.
// ---------------------------------------------------------------------------

// `sql` runs one parameterized query at a time. Values passed via the tagged
// template (e.g. sql`... ${uid}`) are sent as parameters, so they are safe
// from SQL injection.
//
// Created lazily on first use so DATABASE_URL is only read at request time
// (not while Next.js builds the project). Call it as a tagged template:
//   const rows = await getSql()`SELECT ...`;
let _sql: ReturnType<typeof neon> | null = null;
function getSql() {
  if (!_sql) _sql = neon(env.DATABASE_URL);
  return _sql;
}

// -- Schema -----------------------------------------------------------------
// Create the tables if they don't exist. This runs at most once per warm
// server instance (memoized below) and is also exposed via /api/setup.
let schemaReady: Promise<void> | null = null;

export function ensureSchema(): Promise<void> {
  if (!schemaReady) {
    schemaReady = (async () => {
      // One shared coin wallet per Whop user, used across all games.
      await getSql()`
        CREATE TABLE IF NOT EXISTS balances (
          whop_user_id TEXT PRIMARY KEY,
          coins        INTEGER NOT NULL DEFAULT 0,
          updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
        )
      `;
      // Idempotency: every processed webhook event id is stored here so the
      // same purchase can never be credited twice.
      await getSql()`
        CREATE TABLE IF NOT EXISTS processed_events (
          event_id     TEXT PRIMARY KEY,
          processed_at TIMESTAMPTZ NOT NULL DEFAULT now()
        )
      `;
      // Items a player has unlocked by spending coins.
      await getSql()`
        CREATE TABLE IF NOT EXISTS unlocks (
          whop_user_id TEXT NOT NULL,
          item_id      TEXT NOT NULL,
          created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
          PRIMARY KEY (whop_user_id, item_id)
        )
      `;
    })().catch((err) => {
      // Reset so a later request can retry if the first attempt failed.
      schemaReady = null;
      throw err;
    });
  }
  return schemaReady;
}

// -- Balance ----------------------------------------------------------------

/** Return a player's coin balance (0 if they have no wallet row yet). */
export async function getBalance(whopUserId: string): Promise<number> {
  await ensureSchema();
  const rows = (await getSql()`
    SELECT coins FROM balances WHERE whop_user_id = ${whopUserId}
  `) as { coins: number }[];
  return rows.length > 0 ? rows[0].coins : 0;
}

/**
 * Credit coins for a webhook event, exactly once.
 *
 * This is a SINGLE atomic statement:
 *   - It inserts the event id into processed_events. If that id already exists
 *     (a duplicate/retried webhook), the INSERT does nothing and the follow-up
 *     balance update is skipped — so coins are added at most once per event.
 *   - Otherwise it adds the coins to the player's wallet (creating the wallet
 *     row if needed).
 *
 * Returns the new balance, or `null` if the event was already processed.
 */
export async function creditCoinsOnce(
  eventId: string,
  whopUserId: string,
  coins: number
): Promise<number | null> {
  await ensureSchema();
  const rows = (await getSql()`
    WITH new_event AS (
      INSERT INTO processed_events (event_id)
      VALUES (${eventId})
      ON CONFLICT (event_id) DO NOTHING
      RETURNING event_id
    )
    INSERT INTO balances (whop_user_id, coins, updated_at)
    SELECT ${whopUserId}, ${coins}, now()
    FROM new_event
    ON CONFLICT (whop_user_id)
    DO UPDATE SET coins = balances.coins + ${coins}, updated_at = now()
    RETURNING coins
  `) as { coins: number }[];
  // No row returned => the event id already existed => already credited.
  return rows.length > 0 ? rows[0].coins : null;
}

// -- Spending ---------------------------------------------------------------

export type SpendResult =
  | { status: "ok"; coins: number }
  | { status: "already_owned" }
  | { status: "insufficient" };

/**
 * Spend coins to unlock an item, atomically and safely.
 *
 * In one statement it:
 *   - checks whether the player already owns the item (if so, no charge),
 *   - deducts the price ONLY if they have enough AND don't already own it,
 *   - records the unlock.
 *
 * The deduction condition `coins >= price` runs inside the UPDATE, so two
 * simultaneous spends can never drive the balance negative.
 */
export async function spendCoins(
  whopUserId: string,
  itemId: string,
  price: number
): Promise<SpendResult> {
  await ensureSchema();
  const rows = (await getSql()`
    WITH already AS (
      SELECT 1 AS owned
      FROM unlocks
      WHERE whop_user_id = ${whopUserId} AND item_id = ${itemId}
    ),
    deducted AS (
      UPDATE balances
      SET coins = coins - ${price}, updated_at = now()
      WHERE whop_user_id = ${whopUserId}
        AND coins >= ${price}
        AND NOT EXISTS (SELECT 1 FROM already)
      RETURNING coins
    ),
    recorded AS (
      INSERT INTO unlocks (whop_user_id, item_id)
      SELECT ${whopUserId}, ${itemId} FROM deducted
      ON CONFLICT (whop_user_id, item_id) DO NOTHING
      RETURNING item_id
    )
    SELECT
      EXISTS (SELECT 1 FROM already) AS already_owned,
      (SELECT coins FROM deducted)   AS new_balance
  `) as { already_owned: boolean; new_balance: number | null }[];

  const row = rows[0];
  if (row?.already_owned) return { status: "already_owned" };
  if (row?.new_balance === null || row?.new_balance === undefined) {
    return { status: "insufficient" };
  }
  return { status: "ok", coins: row.new_balance };
}

// -- Unlocks ----------------------------------------------------------------

/** Return the ids of every item a player owns. */
export async function getUnlocks(whopUserId: string): Promise<string[]> {
  await ensureSchema();
  const rows = (await getSql()`
    SELECT item_id FROM unlocks
    WHERE whop_user_id = ${whopUserId}
    ORDER BY created_at ASC
  `) as { item_id: string }[];
  return rows.map((r) => r.item_id);
}
