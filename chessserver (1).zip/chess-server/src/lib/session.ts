import crypto from "node:crypto";
import { env } from "./env";

// ---------------------------------------------------------------------------
// Login sessions
//
// After a player logs in with Whop we give the browser a signed cookie that
// says "this browser is Whop user X". The cookie is signed with SESSION_SECRET
// (HMAC-SHA256), so the browser cannot forge or change it. The server always
// derives the player's identity from this cookie — never from anything the
// browser puts in a request body.
// ---------------------------------------------------------------------------

export const SESSION_COOKIE = "wcs_session";

// How long a login lasts.
const MAX_AGE_SECONDS = 60 * 60 * 24 * 30; // 30 days

function base64urlEncode(buf: Buffer): string {
  return buf.toString("base64url");
}

function base64urlDecode(str: string): Buffer {
  return Buffer.from(str, "base64url");
}

function sign(data: string): Buffer {
  return crypto.createHmac("sha256", env.SESSION_SECRET).update(data).digest();
}

interface SessionPayload {
  sub: string; // the Whop user id
  exp: number; // expiry, unix seconds
}

/** Create a signed session token for a Whop user id. */
export function createSessionToken(whopUserId: string): string {
  const payload: SessionPayload = {
    sub: whopUserId,
    exp: Math.floor(Date.now() / 1000) + MAX_AGE_SECONDS,
  };
  const body = base64urlEncode(Buffer.from(JSON.stringify(payload)));
  const signature = base64urlEncode(sign(body));
  return `${body}.${signature}`;
}

/**
 * Verify a session token and return the Whop user id, or `null` if the token
 * is missing, tampered with, or expired.
 */
export function verifySessionToken(token: string | undefined | null): string | null {
  if (!token) return null;
  const parts = token.split(".");
  if (parts.length !== 2) return null;
  const [body, signature] = parts;

  const expected = base64urlEncode(sign(body));
  const a = Buffer.from(signature);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;

  try {
    const payload = JSON.parse(base64urlDecode(body).toString("utf8")) as SessionPayload;
    if (typeof payload.sub !== "string" || payload.sub.length === 0) return null;
    if (typeof payload.exp !== "number" || payload.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return payload.sub;
  } catch {
    return null;
  }
}

// Cookie options for the session.
//
// SameSite=None + Secure is required because the game is on a different origin
// and its fetch() calls must be allowed to send this cookie. The cookie stays
// HttpOnly so JavaScript in the browser can never read it.
export const sessionCookieOptions = {
  httpOnly: true,
  secure: true,
  sameSite: "none" as const,
  path: "/",
  maxAge: MAX_AGE_SECONDS,
};

// Options used to clear the session (log out).
export const clearSessionCookieOptions = {
  ...sessionCookieOptions,
  maxAge: 0,
};
