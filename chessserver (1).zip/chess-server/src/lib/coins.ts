// ===========================================================================
// COIN PACK PRICING  ——  EDIT THIS TABLE TO CHANGE YOUR PRICES / COIN AMOUNTS
// ===========================================================================
//
// Coins are credited based on the PRICE THE PLAYER PAID (in US dollars), NOT
// the product id. When a Whop "payment.succeeded" webhook arrives, the server
// looks up the amount paid in this table and credits the matching coins.
//
//   - The "usd" column is the exact price of the coin pack in US dollars.
//   - The "coins" column is how many coins to add to the player's wallet.
//
// Matching is EXACT, to the cent (so 78.99 must be paid exactly). If a payment
// amount is not in this table, NOTHING is credited and a warning is logged —
// the server never guesses.
//
// To add / change a pack, just edit a line below and redeploy.
// ===========================================================================

export interface CoinPack {
  usd: number; // price the player pays, in US dollars
  coins: number; // coins credited for that price
}

export const COIN_PACKS: CoinPack[] = [
  { usd: 2, coins: 1000 },
  { usd: 3, coins: 2500 },
  { usd: 4, coins: 5000 },
  { usd: 7, coins: 10000 },
  { usd: 14, coins: 20000 },
  { usd: 24, coins: 30000 },
  { usd: 39, coins: 50000 },
  { usd: 78.99, coins: 100000 },
];

// Work in integer cents so that floating-point prices like 78.99 compare
// exactly and safely.
function toCents(usd: number): number {
  return Math.round(usd * 100);
}

/**
 * Given an amount paid in US dollars, return how many coins to credit.
 * Returns `null` if the amount does not exactly match a pack in the table.
 */
export function coinsForAmountUsd(amountUsd: number): number | null {
  if (!Number.isFinite(amountUsd) || amountUsd <= 0) return null;
  const cents = toCents(amountUsd);
  const pack = COIN_PACKS.find((p) => toCents(p.usd) === cents);
  return pack ? pack.coins : null;
}
