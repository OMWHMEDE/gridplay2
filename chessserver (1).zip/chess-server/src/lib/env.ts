// ---------------------------------------------------------------------------
// Environment variables
//
// Every secret lives in an environment variable — nothing is hard-coded.
// Each value is read lazily and, if missing, throws a clear error naming the
// variable so problems are easy to diagnose in the Vercel logs.
// ---------------------------------------------------------------------------

function required(name: string): string {
  const value = process.env[name];
  if (!value || value.length === 0) {
    throw new Error(
      `Missing required environment variable "${name}". ` +
        `Set it in Vercel (Project Settings → Environment Variables) ` +
        `or in your local .env.local file.`
    );
  }
  return value;
}

function optional(name: string): string | undefined {
  const value = process.env[name];
  return value && value.length > 0 ? value : undefined;
}

// Getters so that a missing variable only errors when it is actually used at
// request time — not while Next.js is building the project.
export const env = {
  get WHOP_APP_ID() {
    return required("WHOP_APP_ID");
  },
  get WHOP_API_KEY() {
    return required("WHOP_API_KEY");
  },
  get WHOP_CLIENT_SECRET() {
    return required("WHOP_CLIENT_SECRET");
  },
  get WHOP_BUSINESS_ID() {
    return required("WHOP_BUSINESS_ID");
  },
  get WHOP_WEBHOOK_SECRET() {
    return required("WHOP_WEBHOOK_SECRET");
  },
  get DATABASE_URL() {
    return required("DATABASE_URL");
  },
  get SESSION_SECRET() {
    return required("SESSION_SECRET");
  },
  get GAME_ORIGIN() {
    return required("GAME_ORIGIN");
  },
  // Optional: explicit public URL of this server. Falls back to the request.
  get PUBLIC_URL() {
    return optional("PUBLIC_URL");
  },
};

// The first GAME_ORIGIN entry — used as the place to send players back to
// after they finish logging in with Whop.
export function primaryGameOrigin(): string {
  return env.GAME_ORIGIN.split(",")[0].trim().replace(/\/$/, "");
}
