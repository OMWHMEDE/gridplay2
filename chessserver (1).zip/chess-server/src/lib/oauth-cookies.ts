// Cookie names used to carry the PKCE verifier and CSRF state between the
// /api/auth/login and /api/auth/callback steps. Kept here (not in a route
// file) because Next.js route files may only export request handlers.

export const STATE_COOKIE = "wcs_oauth_state";
export const VERIFIER_COOKIE = "wcs_oauth_verifier";

// Short-lived cookie options for the OAuth handshake. SameSite=Lax so they
// survive the top-level redirect back from Whop; HttpOnly so page JS can't
// read them.
export const TEMP_COOKIE_OPTIONS = {
  httpOnly: true,
  secure: true,
  sameSite: "lax" as const,
  path: "/",
  maxAge: 10 * 60, // 10 minutes to complete login
};

// Options used to delete the temporary OAuth cookies.
export const CLEAR_TEMP_COOKIE_OPTIONS = {
  ...TEMP_COOKIE_OPTIONS,
  maxAge: 0,
};
