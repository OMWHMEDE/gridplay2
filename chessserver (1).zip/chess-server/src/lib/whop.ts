import crypto from "node:crypto";
import { env } from "./env";

// ---------------------------------------------------------------------------
// Login with Whop (OAuth 2.1 + PKCE)
//
// Flow:
//   1. /api/auth/login builds an authorize URL and sends the player to Whop.
//   2. Player approves; Whop redirects back to /api/auth/callback with a code.
//   3. We exchange the code for an access token, then fetch the user's profile.
//
// PKCE (a "code_verifier" / "code_challenge" pair) protects the flow even
// though we also authenticate with the confidential client secret.
// ---------------------------------------------------------------------------

export const WHOP_AUTHORIZE_URL = "https://api.whop.com/oauth/authorize";
export const WHOP_TOKEN_URL = "https://api.whop.com/oauth/token";
export const WHOP_USERINFO_URL = "https://api.whop.com/oauth/userinfo";

// Scopes requested from Whop. openid = "who is this user", profile = name/
// username, email = email address.
export const OAUTH_SCOPES = "openid profile email";

/** Create a PKCE verifier + its S256 challenge. */
export function createPkce(): { verifier: string; challenge: string } {
  const verifier = crypto.randomBytes(32).toString("base64url");
  const challenge = crypto
    .createHash("sha256")
    .update(verifier)
    .digest("base64url");
  return { verifier, challenge };
}

/** A random, URL-safe value for CSRF protection (the OAuth "state"). */
export function randomToken(): string {
  return crypto.randomBytes(16).toString("base64url");
}

/** Build the URL to send the player to for Login with Whop. */
export function buildAuthorizeUrl(params: {
  redirectUri: string;
  state: string;
  codeChallenge: string;
}): string {
  const url = new URL(WHOP_AUTHORIZE_URL);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("client_id", env.WHOP_APP_ID);
  url.searchParams.set("redirect_uri", params.redirectUri);
  url.searchParams.set("scope", OAUTH_SCOPES);
  url.searchParams.set("state", params.state);
  url.searchParams.set("code_challenge", params.codeChallenge);
  url.searchParams.set("code_challenge_method", "S256");
  return url.toString();
}

interface TokenResponse {
  access_token: string;
  token_type?: string;
  expires_in?: number;
  scope?: string;
}

// -- TEMPORARY DIAGNOSTIC HELPER (safe to remove once login works) -----------
// Masks a value so it can be logged: shows only the first 6 and last 6 chars,
// plus length and whether there is hidden leading/trailing whitespace (a very
// common cause of "client_secret is invalid" after pasting into Vercel).
function maskForLog(value: string | undefined): Record<string, unknown> {
  if (value === undefined) return { present: false };
  const trimmed = value.trim();
  return {
    present: true,
    length: value.length,
    trimmedLength: trimmed.length,
    hasSurroundingWhitespace: value !== trimmed,
    preview:
      value.length <= 12
        ? "<value too short to mask>"
        : `${value.slice(0, 6)}…${value.slice(-6)}`,
  };
}

/** Exchange the authorization code for an access token. */
export async function exchangeCodeForToken(params: {
  code: string;
  redirectUri: string;
  codeVerifier: string;
}): Promise<string> {
  // Read straight from process.env HERE, at request time, to prove these are
  // NOT baked in at build time. (The routes are runtime="nodejs" +
  // dynamic="force-dynamic", so this runs on every request on the server.)
  const rawClientSecret = process.env.WHOP_CLIENT_SECRET;
  const rawAppId = process.env.WHOP_APP_ID;

  // --- TEMPORARY DIAGNOSTIC LOG (masked; safe to view; remove later) --------
  console.error("[whop-token-exchange] DIAGNOSTIC", {
    tokenUrl: WHOP_TOKEN_URL,
    readAt: new Date().toISOString(), // proves values are read at request time
    // The client secret is sent as the body param named exactly "client_secret"
    // (see the URLSearchParams below). This is the value it will send:
    clientSecretParamName: "client_secret",
    WHOP_CLIENT_SECRET: maskForLog(rawClientSecret),
    // The client id is sent as the body param named exactly "client_id":
    clientIdParamName: "client_id",
    WHOP_APP_ID: maskForLog(rawAppId),
    // Sanity check that the getter and the raw read agree (rules out a wrong
    // variable name being read somewhere else):
    getterMatchesRaw: env.WHOP_CLIENT_SECRET === rawClientSecret,
  });
  // --------------------------------------------------------------------------

  const body = new URLSearchParams({
    grant_type: "authorization_code",
    code: params.code,
    redirect_uri: params.redirectUri,
    client_id: env.WHOP_APP_ID, // <-- client id param sent to Whop
    client_secret: env.WHOP_CLIENT_SECRET, // <-- client secret param sent to Whop
    code_verifier: params.codeVerifier,
  });

  const res = await fetch(WHOP_TOKEN_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
    },
    body: body.toString(),
    cache: "no-store",
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Whop token exchange failed (${res.status}): ${text}`);
  }

  const data = (await res.json()) as TokenResponse;
  if (!data.access_token) {
    throw new Error("Whop token exchange returned no access_token");
  }
  return data.access_token;
}

export interface WhopUser {
  id: string; // the Whop user id (from "sub")
  email?: string;
  username?: string;
  name?: string;
}

/** Fetch the logged-in user's profile using their access token. */
export async function fetchWhopUser(accessToken: string): Promise<WhopUser> {
  const res = await fetch(WHOP_USERINFO_URL, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      Accept: "application/json",
    },
    cache: "no-store",
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Whop userinfo failed (${res.status}): ${text}`);
  }

  const data = (await res.json()) as Record<string, unknown>;
  const id = (data.sub ?? data.id) as string | undefined;
  if (!id) {
    throw new Error("Whop userinfo returned no user id");
  }
  return {
    id,
    email: data.email as string | undefined,
    username: data.preferred_username as string | undefined,
    name: data.name as string | undefined,
  };
}
