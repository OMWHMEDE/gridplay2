import crypto from "node:crypto";
import { env } from "./env";

// ---------------------------------------------------------------------------
// Whop webhook verification
//
// Whop signs webhooks using the "Standard Webhooks" spec. Each request has:
//   webhook-id         a unique id for this delivery
//   webhook-timestamp  unix seconds when it was sent
//   webhook-signature  one or more signatures, each like "v1,<base64>"
//
// We recompute the signature over `${id}.${timestamp}.${rawBody}` using the
// webhook secret and compare it to what Whop sent. If nothing matches (or the
// timestamp is too old), the webhook is rejected. This proves the webhook is
// genuinely from Whop and hasn't been tampered with or replayed.
// ---------------------------------------------------------------------------

// Reject deliveries whose timestamp is more than this many seconds off — this
// blocks replay attacks with an old-but-valid signature.
const TOLERANCE_SECONDS = 5 * 60;

// Turn the configured secret into the raw key bytes. Standard Webhooks secrets
// look like "whsec_<base64>"; we strip the prefix and base64-decode. If the
// secret isn't valid base64, we fall back to using its raw bytes.
function secretKey(): Buffer {
  let secret = env.WHOP_WEBHOOK_SECRET;
  if (secret.startsWith("whsec_")) secret = secret.slice("whsec_".length);
  try {
    const decoded = Buffer.from(secret, "base64");
    // Guard against strings that "decode" but aren't really base64.
    if (decoded.length > 0 && decoded.toString("base64").replace(/=+$/, "") === secret.replace(/=+$/, "")) {
      return decoded;
    }
  } catch {
    /* fall through */
  }
  return Buffer.from(secret, "utf8");
}

function timingSafeEqualStr(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

/**
 * Verify a Whop webhook. Returns true only if the signature is valid and the
 * timestamp is recent.
 *
 * @param rawBody the EXACT raw request body string (do not re-serialize JSON)
 * @param headers the request headers
 */
export function verifyWhopWebhook(rawBody: string, headers: Headers): boolean {
  const id = headers.get("webhook-id");
  const timestamp = headers.get("webhook-timestamp");
  const signatureHeader = headers.get("webhook-signature");
  if (!id || !timestamp || !signatureHeader) return false;

  // Timestamp freshness check.
  const ts = Number(timestamp);
  if (!Number.isFinite(ts)) return false;
  const now = Math.floor(Date.now() / 1000);
  if (Math.abs(now - ts) > TOLERANCE_SECONDS) return false;

  // Compute the expected signature.
  const signedContent = `${id}.${timestamp}.${rawBody}`;
  const expected = crypto
    .createHmac("sha256", secretKey())
    .update(signedContent)
    .digest("base64");

  // The header can hold several space-separated signatures; each is "v1,<sig>".
  // Accept if any of them matches.
  for (const part of signatureHeader.split(" ")) {
    const comma = part.indexOf(",");
    const sig = comma === -1 ? part : part.slice(comma + 1);
    if (sig && timingSafeEqualStr(sig, expected)) return true;
  }
  return false;
}

// ---------------------------------------------------------------------------
// Reading the payment payload
//
// Whop's payload looks like:  { id, type, company_id, data: { ... } }
// Field names for the amount and user vary a little between Whop API versions,
// so we defensively check several. We want the GROSS amount the customer paid
// (to match the price table), not the amount left after Whop's fees.
// ---------------------------------------------------------------------------

export interface ParsedPayment {
  eventId: string; // unique id for idempotency (the webhook-id)
  type: string; // e.g. "payment.succeeded"
  companyId?: string;
  amountUsd: number | null; // gross amount paid, in USD
  currency?: string;
  whopUserId: string | null; // the paying user's Whop id (user_xxx)
}

function firstNumber(obj: Record<string, unknown>, keys: string[]): number | null {
  for (const key of keys) {
    const value = obj[key];
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value === "string" && value.trim() !== "" && Number.isFinite(Number(value))) {
      return Number(value);
    }
  }
  return null;
}

function firstString(obj: Record<string, unknown>, keys: string[]): string | undefined {
  for (const key of keys) {
    const value = obj[key];
    if (typeof value === "string" && value.length > 0) return value;
  }
  return undefined;
}

export function parsePayment(eventId: string, payload: unknown): ParsedPayment {
  const root = (payload ?? {}) as Record<string, unknown>;
  const type = (root.type ?? root.action ?? "") as string;
  const companyId = firstString(root, ["company_id", "business_id"]);
  const data = (root.data ?? {}) as Record<string, unknown>;

  // Gross amount the customer paid. We prefer the pre-fee/list price fields and
  // only fall back to "amount_after_fees" as a last resort.
  const amountUsd = firstNumber(data, [
    "final_amount",
    "subtotal",
    "amount",
    "settled_usd_amount",
    "usd_amount",
    "amount_after_fees",
  ]);

  const currency = firstString(data, ["currency"]);

  // The paying user. Prefer a real user id (user_xxx); fall back to nested
  // objects. NOTE: this must match the id returned by Login with Whop (the
  // "sub" from userinfo) so balances line up.
  let whopUserId = firstString(data, ["user_id", "user"]);
  if (!whopUserId && data.user && typeof data.user === "object") {
    whopUserId = firstString(data.user as Record<string, unknown>, ["id"]);
  }
  if (!whopUserId && data.member && typeof data.member === "object") {
    const member = data.member as Record<string, unknown>;
    whopUserId = firstString(member, ["user_id", "user"]) ??
      firstString(member, ["id"]);
  }

  return {
    eventId,
    type,
    companyId,
    amountUsd,
    currency,
    whopUserId: whopUserId ?? null,
  };
}
