import { NextRequest, NextResponse } from "next/server";

// ---------------------------------------------------------------------------
// CORS (Cross-Origin Resource Sharing)
//
// The browser game is on a DIFFERENT domain than this server (e.g.
// https://omwhmede.github.io calling https://chess-server-....vercel.app).
// For the browser to send the login cookie on those cross-site fetch()
// requests, every response MUST include:
//
//   Access-Control-Allow-Origin: <the exact game origin>   (NOT "*")
//   Access-Control-Allow-Credentials: true
//
// A "*" wildcard is forbidden by the browser when credentials are involved,
// so we echo back the caller's origin only if it is one of our allowed
// GAME_ORIGIN values. Anything else gets no CORS headers and is blocked.
//
// We read process.env directly (not the throwing env helper) so a missing
// GAME_ORIGIN fails closed — no headers — instead of 500-ing the request.
// ---------------------------------------------------------------------------

function allowedOrigins(): string[] {
  return (process.env.GAME_ORIGIN ?? "")
    .split(",")
    .map((o) => o.trim().replace(/\/$/, ""))
    .filter(Boolean);
}

/** Return the caller's origin if it is allowed, otherwise null. */
export function allowedOrigin(req: NextRequest): string | null {
  const origin = req.headers.get("origin");
  if (!origin) return null;
  return allowedOrigins().includes(origin.replace(/\/$/, "")) ? origin : null;
}

/** Add CORS headers to a response for an allowed origin (mutates and returns it). */
export function withCors(req: NextRequest, res: NextResponse): NextResponse {
  const origin = allowedOrigin(req);
  if (origin) {
    res.headers.set("Access-Control-Allow-Origin", origin);
    res.headers.set("Access-Control-Allow-Credentials", "true");
    // Responses differ by Origin, so caches must key on it.
    res.headers.set("Vary", "Origin");
  }
  return res;
}

/**
 * Handle a CORS preflight (OPTIONS) request. Browsers send this automatically
 * before a credentialed cross-site fetch; it must return the same allow
 * headers plus the permitted methods/headers.
 */
export function handlePreflight(req: NextRequest): NextResponse {
  const res = new NextResponse(null, { status: 204 });
  const origin = allowedOrigin(req);
  if (origin) {
    res.headers.set("Access-Control-Allow-Origin", origin);
    res.headers.set("Access-Control-Allow-Credentials", "true");
    res.headers.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.headers.set("Access-Control-Allow-Headers", "Content-Type");
    res.headers.set("Access-Control-Max-Age", "86400");
    res.headers.set("Vary", "Origin");
  }
  return res;
}
