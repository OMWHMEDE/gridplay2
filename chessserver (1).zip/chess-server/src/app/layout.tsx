export const metadata = {
  title: "Whop Coin Server",
  description: "Backend API for selling virtual coins through Whop.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
