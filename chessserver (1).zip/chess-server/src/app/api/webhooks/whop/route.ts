import { NextRequest } from "next/server";
import { verifyWhopWebhook, parsePayment } from "@/lib/webhook";
import { coinsForAmountUsd } from "@/lib/coins";
import { creditCoinsOnce } from "@/lib/db";
import { env } from "@/lib/env";

// Use the Node.js runtime (we need node:crypto for signature checks) and never
// cache — every webhook must be processed.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ---------------------------------------------------------------------------
// POST /api/webhooks/whop
//
// Whop calls this when something happens (like a successful payment). We:
//   1. verify the signature (reject with 401 if invalid),
//   2. ignore anything that isn't a successful payment,
//   3. map the amount paid to coins using the price table,
//   4. credit the coins exactly once (idempotent),
//   5. return 200 quickly.
// ---------------------------------------------------------------------------
export async function POST(req: NextRequest) {
  // IMPORTANT: read the RAW body. The signature is computed over these exact
  // bytes, so we must not JSON.parse-and-re-stringify before verifying.
  const rawBody = await req.text();

  // 1. Verify the signature.
  if (!verifyWhopWebhook(rawBody, req.headers)) {
    console.warn("[whop-webhook] rejected: invalid or missing signature");
    return new Response("Invalid signature", { status: 401 });
  }

  // Parse the (now trusted) JSON.
  let payload: unknown;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    // Signed but not JSON — acknowledge so Whop stops retrying.
    return new Response("ok", { status: 200 });
  }

  // The webhook-id doubles as our idempotency key.
  const eventId = req.headers.get("webhook-id") ?? "";
  const payment = parsePayment(eventId, payload);

  // 2. Only act on successful payments; acknowledge everything else.
  if (payment.type !== "payment.succeeded") {
    return new Response("ignored", { status: 200 });
  }

  // Optional safety: make sure the payment belongs to our business.
  if (payment.companyId && payment.companyId !== env.WHOP_BUSINESS_ID) {
    console.warn(
      `[whop-webhook] ignoring payment for a different business (${payment.companyId})`
    );
    return new Response("ignored", { status: 200 });
  }

  if (!eventId) {
    console.warn("[whop-webhook] missing webhook-id; cannot ensure idempotency");
    return new Response("ok", { status: 200 });
  }

  if (!payment.whopUserId) {
    console.warn("[whop-webhook] payment has no user id; crediting nothing", {
      eventId,
    });
    return new Response("ok", { status: 200 });
  }

  // Only credit USD payments (the price table is in USD).
  if (payment.currency && payment.currency.toLowerCase() !== "usd") {
    console.warn("[whop-webhook] non-USD payment; crediting nothing", {
      eventId,
      currency: payment.currency,
    });
    return new Response("ok", { status: 200 });
  }

  // 3. Map amount -> coins.
  const coins =
    payment.amountUsd !== null ? coinsForAmountUsd(payment.amountUsd) : null;
  if (coins === null) {
    console.warn(
      "[whop-webhook] amount does not match any coin pack; crediting nothing",
      { eventId, amountUsd: payment.amountUsd }
    );
    return new Response("ok", { status: 200 });
  }

  // 4. Credit exactly once.
  try {
    const newBalance = await creditCoinsOnce(eventId, payment.whopUserId, coins);
    if (newBalance === null) {
      console.log("[whop-webhook] duplicate event, already credited", { eventId });
    } else {
      console.log("[whop-webhook] credited coins", {
        eventId,
        whopUserId: payment.whopUserId,
        coins,
        newBalance,
      });
    }
  } catch (err) {
    // Return 500 so Whop retries later (our idempotency guard makes retries safe).
    console.error("[whop-webhook] database error while crediting", err);
    return new Response("error", { status: 500 });
  }

  // 5. Acknowledge.
  return new Response("ok", { status: 200 });
}
