import { NextRequest, NextResponse } from "next/server";
import { SESSION_COOKIE, clearSessionCookieOptions } from "@/lib/session";
import { withCors, handlePreflight } from "@/lib/cors";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Answer the browser's CORS preflight for the game's fetch().
export function OPTIONS(req: NextRequest) {
  return handlePreflight(req);
}

// ---------------------------------------------------------------------------
// POST /api/auth/logout
//
// Clears the session cookie. The game can call this to log the player out.
// ---------------------------------------------------------------------------
export async function POST(req: NextRequest) {
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, "", clearSessionCookieOptions);
  return withCors(req, res);
}
