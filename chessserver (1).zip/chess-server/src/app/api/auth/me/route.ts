import { NextRequest } from "next/server";
import { getPlayerId, json } from "@/lib/http";
import { withCors, handlePreflight } from "@/lib/cors";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Answer the browser's CORS preflight for the game's fetch().
export function OPTIONS(req: NextRequest) {
  return handlePreflight(req);
}

// ---------------------------------------------------------------------------
// GET /api/auth/me
//
// Tells the game whether the current browser is logged in. Handy for showing a
// "Log in" vs "Logged in" state. Only returns the Whop user id — no secrets.
// ---------------------------------------------------------------------------
export async function GET(req: NextRequest) {
  const playerId = getPlayerId(req);
  if (!playerId) {
    return withCors(req, json({ loggedIn: false }));
  }
  return withCors(req, json({ loggedIn: true, whopUserId: playerId }));
}
