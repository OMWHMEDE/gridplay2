import { NextRequest, NextResponse } from "next/server";
import { getRedirectUri } from "@/lib/http";
import { buildAuthorizeUrl, createPkce, randomToken } from "@/lib/whop";
import {
  STATE_COOKIE,
  VERIFIER_COOKIE,
  TEMP_COOKIE_OPTIONS,
} from "@/lib/oauth-cookies";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ---------------------------------------------------------------------------
// GET /api/auth/login
//
// Starts "Login with Whop". Point the player's browser here (a normal link or
// redirect from your game). We generate PKCE + state, stash them in cookies,
// and send the player to Whop to approve.
// ---------------------------------------------------------------------------
export async function GET(req: NextRequest) {
  const { verifier, challenge } = createPkce();
  const state = randomToken();
  const redirectUri = getRedirectUri(req);

  const authorizeUrl = buildAuthorizeUrl({
    redirectUri,
    state,
    codeChallenge: challenge,
  });

  const res = NextResponse.redirect(authorizeUrl);
  res.cookies.set(STATE_COOKIE, state, TEMP_COOKIE_OPTIONS);
  res.cookies.set(VERIFIER_COOKIE, verifier, TEMP_COOKIE_OPTIONS);
  return res;
}
