import { NextRequest, NextResponse } from "next/server";
import { getRedirectUri } from "@/lib/http";
import { exchangeCodeForToken, fetchWhopUser } from "@/lib/whop";
import {
  SESSION_COOKIE,
  createSessionToken,
  sessionCookieOptions,
} from "@/lib/session";
import { primaryGameOrigin } from "@/lib/env";
import {
  STATE_COOKIE,
  VERIFIER_COOKIE,
  CLEAR_TEMP_COOKIE_OPTIONS as CLEAR_TEMP,
} from "@/lib/oauth-cookies";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ---------------------------------------------------------------------------
// GET /api/auth/callback
//
// Whop redirects the player back here after they approve. We validate the
// state (CSRF check), exchange the code for a token, look up who they are, set
// a signed session cookie, and send them back to the game.
// ---------------------------------------------------------------------------
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const error = url.searchParams.get("error");

  const game = primaryGameOrigin();

  if (error) {
    return NextResponse.redirect(`${game}?login=denied`);
  }

  const savedState = req.cookies.get(STATE_COOKIE)?.value;
  const verifier = req.cookies.get(VERIFIER_COOKIE)?.value;

  // CSRF protection: the state we sent must come back unchanged.
  if (!code || !state || !savedState || !verifier || state !== savedState) {
    return NextResponse.redirect(`${game}?login=failed`);
  }

  try {
    const accessToken = await exchangeCodeForToken({
      code,
      redirectUri: getRedirectUri(req),
      codeVerifier: verifier,
    });

    const user = await fetchWhopUser(accessToken);

    // Success — set the signed session cookie and send the player to the game.
    const res = NextResponse.redirect(`${game}?login=success`);
    res.cookies.set(SESSION_COOKIE, createSessionToken(user.id), sessionCookieOptions);
    // Clean up the temporary OAuth cookies.
    res.cookies.set(STATE_COOKIE, "", CLEAR_TEMP);
    res.cookies.set(VERIFIER_COOKIE, "", CLEAR_TEMP);

    // Log (to Vercel) that the session cookie was set and with which options,
    // so a cross-domain cookie problem can be confirmed after a test login.
    // NOTE: we log the cookie NAME and OPTIONS only — never the signed value.
    console.error("[auth/callback] session cookie set before redirect", {
      whopUserId: user.id,
      cookieName: SESSION_COOKIE,
      options: sessionCookieOptions, // expect sameSite:"none", secure:true, httpOnly:true
      redirectingTo: `${game}?login=success`,
      // whether a Set-Cookie header is actually present on the response (true/false)
      // — never log the value itself, it's a live session credential.
      setCookiePresent: (res.headers.get("set-cookie") ?? "").includes(SESSION_COOKIE),
    });

    return res;
  } catch (err) {
    console.error("[auth/callback] login failed", err);
    return NextResponse.redirect(`${game}?login=failed`);
  }
}
