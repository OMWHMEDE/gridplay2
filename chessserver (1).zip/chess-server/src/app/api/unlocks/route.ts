import { NextRequest } from "next/server";
import { getPlayerId, json } from "@/lib/http";
import { getUnlocks } from "@/lib/db";
import { SHOP_ITEMS } from "@/lib/shop";
import { withCors, handlePreflight } from "@/lib/cors";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Answer the browser's CORS preflight for the game's fetch().
export function OPTIONS(req: NextRequest) {
  return handlePreflight(req);
}

// ---------------------------------------------------------------------------
// GET /api/unlocks
//
// Returns the ids of items the logged-in player owns, plus the full shop list
// (with prices) so the game can render the store without hard-coding prices.
// ---------------------------------------------------------------------------
export async function GET(req: NextRequest) {
  const playerId = getPlayerId(req);
  if (!playerId) {
    return withCors(req, json({ error: "not_logged_in" }, 401));
  }

  try {
    const owned = await getUnlocks(playerId);
    return withCors(req, json({ owned, shop: SHOP_ITEMS }));
  } catch (err) {
    console.error("[unlocks] database error", err);
    return withCors(req, json({ error: "server_error" }, 500));
  }
}
