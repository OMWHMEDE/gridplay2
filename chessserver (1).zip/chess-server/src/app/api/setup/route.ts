import { NextRequest } from "next/server";
import { ensureSchema } from "@/lib/db";
import { json } from "@/lib/http";
import { env } from "@/lib/env";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ---------------------------------------------------------------------------
// GET /api/setup?key=YOUR_SESSION_SECRET
//
// Creates the database tables if they don't exist. Tables are also created
// automatically on first use, so this is optional — but you can hit it once
// after deploying to be sure. Protected by your SESSION_SECRET so strangers
// can't trigger it.
// ---------------------------------------------------------------------------
export async function GET(req: NextRequest) {
  const key = new URL(req.url).searchParams.get("key");
  if (!key || key !== env.SESSION_SECRET) {
    return json({ error: "forbidden" }, 403);
  }

  try {
    await ensureSchema();
    return json({ ok: true, message: "Database tables are ready." });
  } catch (err) {
    console.error("[setup] failed", err);
    return json({ error: "setup_failed" }, 500);
  }
}
