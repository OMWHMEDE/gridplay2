import { NextRequest } from "next/server";
import { getPlayerId, json } from "@/lib/http";
import { getBalance } from "@/lib/db";
import { withCors, handlePreflight } from "@/lib/cors";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Answer the browser's CORS preflight for the game's fetch().
export function OPTIONS(req: NextRequest) {
  return handlePreflight(req);
}

// ---------------------------------------------------------------------------
// GET /api/balance
//
// Returns the logged-in player's coin balance. The player is identified from
// their session cookie, set at login — the browser cannot pass a user id.
//
// EVERY response (including the 401) carries CORS headers, so the game can
// read the result and tell "not logged in" (a clean 401 JSON) apart from
// "cookie blocked by the browser" (a CORS/network error).
// ---------------------------------------------------------------------------
export async function GET(req: NextRequest) {
  const playerId = getPlayerId(req);
  if (!playerId) {
    return withCors(req, json({ error: "not_logged_in" }, 401));
  }

  try {
    const coins = await getBalance(playerId);
    return withCors(req, json({ coins }));
  } catch (err) {
    console.error("[balance] database error", err);
    return withCors(req, json({ error: "server_error" }, 500));
  }
}
