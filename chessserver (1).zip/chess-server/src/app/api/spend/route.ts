import { NextRequest } from "next/server";
import { getPlayerId, json } from "@/lib/http";
import { getShopItem } from "@/lib/shop";
import { spendCoins } from "@/lib/db";
import { withCors, handlePreflight } from "@/lib/cors";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Answer the browser's CORS preflight for the game's fetch().
export function OPTIONS(req: NextRequest) {
  return handlePreflight(req);
}

// ---------------------------------------------------------------------------
// POST /api/spend   body: { "itemId": "theme_neon" }
//
// Deducts coins for a shop item and records the unlock. The PRICE comes from
// the server's shop list — never from the browser. The player is identified
// from the session cookie. The deduction is atomic and cannot go negative.
// ---------------------------------------------------------------------------
export async function POST(req: NextRequest) {
  const playerId = getPlayerId(req);
  if (!playerId) {
    return withCors(req, json({ error: "not_logged_in" }, 401));
  }

  // Read the item id from the request body.
  let itemId: unknown;
  try {
    const body = (await req.json()) as { itemId?: unknown };
    itemId = body?.itemId;
  } catch {
    return withCors(req, json({ error: "invalid_body" }, 400));
  }

  if (typeof itemId !== "string" || itemId.length === 0) {
    return withCors(req, json({ error: "missing_item_id" }, 400));
  }

  // Look up the real price on the server.
  const item = getShopItem(itemId);
  if (!item) {
    return withCors(req, json({ error: "unknown_item" }, 404));
  }

  try {
    const result = await spendCoins(playerId, item.id, item.price);
    switch (result.status) {
      case "ok":
        return withCors(req, json({ ok: true, itemId: item.id, coins: result.coins }));
      case "already_owned":
        return withCors(req, json({ error: "already_owned", itemId: item.id }, 409));
      case "insufficient":
        return withCors(req, json({ error: "insufficient_coins", price: item.price }, 402));
    }
  } catch (err) {
    console.error("[spend] database error", err);
    return withCors(req, json({ error: "server_error" }, 500));
  }
}
