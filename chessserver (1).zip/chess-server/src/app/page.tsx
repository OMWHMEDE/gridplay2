// This is an API-only server. There is no user interface here — your HTML game
// lives somewhere else and calls the /api/* endpoints. This page just confirms
// the server is running.
export default function Home() {
  return (
    <main style={{ fontFamily: "system-ui, sans-serif", padding: "2rem", lineHeight: 1.6 }}>
      <h1>Whop Coin Server</h1>
      <p>This is the backend API. It has no UI of its own.</p>
      <ul>
        <li><code>POST /api/webhooks/whop</code> — receives Whop payment webhooks</li>
        <li><code>GET&nbsp; /api/auth/login</code> — start Login with Whop</li>
        <li><code>GET&nbsp; /api/balance</code> — logged-in player&apos;s coin balance</li>
        <li><code>POST /api/spend</code> — spend coins on a shop item</li>
        <li><code>GET&nbsp; /api/unlocks</code> — items the player owns</li>
      </ul>
    </main>
  );
}
