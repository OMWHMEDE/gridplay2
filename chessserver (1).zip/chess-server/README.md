# Whop Coin Server

A small, production-ready backend that sells virtual **coins** for your browser
game through [Whop](https://whop.com). It:

- Logs players in with **Login with Whop** (OAuth).
- Receives **Whop payment webhooks** and automatically credits coins based on
  the **price paid** — no codes, no manual work.
- Stores a **single shared coin wallet per player** (used across all your games).
- Lets your game read the balance and spend coins on shop items — securely.

It's built with **Next.js (App Router) + TypeScript**, deploys to **Vercel**
with zero configuration, and uses a **Neon Postgres** database.

> You never touch the code to run it. Follow the steps below.

---

## How coins are priced

Coins are credited by the **amount paid in US dollars**, matched exactly. Edit
the table in [`src/lib/coins.ts`](src/lib/coins.ts):

| Price paid (USD) | Coins credited |
| ---------------- | -------------- |
| $2               | 1,000          |
| $3               | 2,500          |
| $4               | 5,000          |
| $7               | 10,000         |
| $14              | 20,000         |
| $24              | 30,000         |
| $39              | 50,000         |
| $78.99           | 100,000        |

If a payment doesn't match a row **exactly**, nothing is credited and a warning
is logged (the server never guesses).

Shop items that players buy **with coins** live in
[`src/lib/shop.ts`](src/lib/shop.ts) — edit that list to change prices/items.

---

## 1) Environment variables to set in Vercel

Set every one of these in **Vercel → your project → Settings → Environment
Variables** (and, for local testing, in a file named `.env.local`). A template
with comments is in [`.env.example`](.env.example).

| Variable              | What it is                                                                 |
| --------------------- | -------------------------------------------------------------------------- |
| `WHOP_APP_ID`         | Your Whop app id (looks like `app_…`). Also your OAuth client id.          |
| `WHOP_API_KEY`        | Server API key for your Whop app. Keep secret.                             |
| `WHOP_CLIENT_SECRET`  | OAuth client secret for Login with Whop. Keep secret.                      |
| `WHOP_BUSINESS_ID`    | Your Whop business/company id (looks like `biz_…`).                        |
| `WHOP_WEBHOOK_SECRET` | Webhook signing secret from Whop (looks like `whsec_…`). Verifies webhooks.|
| `DATABASE_URL`        | Your Neon Postgres connection string (use the **pooled** one).             |
| `SESSION_SECRET`      | A long random string you generate (see below). Signs login sessions.       |
| `GAME_ORIGIN`         | The exact URL of your game's website, e.g. `https://mygame.com`. Only this origin may call the API. Separate several with commas. |
| `PUBLIC_URL`          | *(optional)* Public URL of this server. Leave unset on Vercel — it's auto-detected. |

Where to find the Whop values: **Whop Dashboard → Developer → your app.** The
`WHOP_WEBHOOK_SECRET` is on the **Webhooks** page (step 4 below).

---

## 2) Generate `SESSION_SECRET`

Run this in a terminal and paste the output as the `SESSION_SECRET` value:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"
```

(No Node.js handy? Any long random string of 40+ characters works.)

---

## 3) Push to GitHub and import into Vercel

1. Create a new **empty** repository on GitHub.
2. Push this project to it:
   ```bash
   git init
   git add .
   git commit -m "Whop coin server"
   git branch -M main
   git remote add origin https://github.com/YOU/YOUR-REPO.git
   git push -u origin main
   ```
3. Go to [vercel.com](https://vercel.com) → **Add New… → Project** → import your
   GitHub repo. Vercel auto-detects Next.js — just click **Deploy**.
4. In Vercel → **Settings → Environment Variables**, add all the variables from
   step 1, then **redeploy** (Deployments → ⋯ → Redeploy) so they take effect.
5. Note your server's URL, e.g. `https://your-project.vercel.app`.

**Get a database (Neon):** create a free project at
[neon.tech](https://neon.tech), copy the **pooled** connection string, and use
it as `DATABASE_URL`. Tables are created automatically the first time the server
runs (or hit `https://your-project.vercel.app/api/setup?key=YOUR_SESSION_SECRET`
once to create them immediately).

---

## 4) Register the Whop webhook

1. In the **Whop Dashboard → Developer → your app → Webhooks**, click **Create
   webhook** (or **Add endpoint**).
2. Set the **URL** to:
   ```
   https://your-project.vercel.app/api/webhooks/whop
   ```
   (replace with your real Vercel URL).
3. Subscribe it to the **`payment.succeeded`** event.
4. Copy the **signing secret** it shows you (starts with `whsec_`) and set it as
   the `WHOP_WEBHOOK_SECRET` environment variable in Vercel, then redeploy.

Also, in your Whop app's **OAuth / Login** settings, add this **redirect URL**:

```
https://your-project.vercel.app/api/auth/callback
```

and make sure the scopes `openid profile email` are enabled.

---

## 5) Test that a purchase credits coins

1. Open `https://your-project.vercel.app/api/auth/login` in your browser and log
   in with Whop. You'll be sent back to your `GAME_ORIGIN` with `?login=success`.
2. Check your balance: open `https://your-project.vercel.app/api/balance` (in the
   same browser). You should see `{"coins":0}`.
3. Make a real purchase of one of your coin packs (or use Whop's webhook test
   tool to send a `payment.succeeded` event for the right amount to your
   business).
4. Refresh `/api/balance` — the coins for that price should now appear.
5. In the **Vercel → Logs**, you'll see a line like
   `[whop-webhook] credited coins { coins: 1000, newBalance: 1000 }`.

If a webhook is sent twice, coins are credited only once (idempotency), and a
payment amount that isn't in the price table credits nothing (with a warning).

---

## The endpoints your game calls

All are under `https://your-project.vercel.app/api`. Browser calls must use
`fetch(url, { credentials: "include" })` so the login cookie is sent, and must
come from your `GAME_ORIGIN`.

| Endpoint                | Method | Purpose                                                     |
| ----------------------- | ------ | ----------------------------------------------------------- |
| `/api/auth/login`       | GET    | Send the player here (link/redirect) to log in with Whop.   |
| `/api/auth/callback`    | GET    | Whop redirects here after login (you don't call it).        |
| `/api/auth/me`          | GET    | `{ loggedIn, whopUserId }` — is this browser logged in?     |
| `/api/auth/logout`      | POST   | Clears the session.                                         |
| `/api/balance`          | GET    | `{ coins }` for the logged-in player.                       |
| `/api/spend`            | POST   | Body `{ "itemId": "theme_neon" }` → spend coins on an item. |
| `/api/unlocks`          | GET    | `{ owned: [...ids], shop: [...items] }`.                    |
| `/api/webhooks/whop`    | POST   | Whop calls this on payment (you don't call it).             |
| `/api/setup`            | GET    | `?key=SESSION_SECRET` → create DB tables (optional).        |

### Security notes

- The browser **never** sees any secret. It only calls `/api/*`.
- A player's identity always comes from the **server-side session cookie** — the
  browser can never pass a user id, price, or coin amount.
- Webhook signatures are verified (Standard Webhooks HMAC-SHA256); invalid or
  unsigned webhooks are rejected with **401**.
- Only your `GAME_ORIGIN` may call the API from a browser (enforced via CORS).
- All coin changes are single atomic SQL statements (safe under concurrency),
  and each purchase is credited **exactly once**.

---

## Cross-domain login troubleshooting

Your game (e.g. `https://omwhmede.github.io`) and this server (e.g.
`https://chess-server-….vercel.app`) are on **different domains**, so the login
cookie is a cross-site cookie. For it to work:

1. **`GAME_ORIGIN` must be the exact origin — scheme + host only, no path and no
   trailing slash.** Correct: `https://omwhmede.github.io`. Wrong:
   `https://omwhmede.github.io/chess/` or `https://omwhmede.github.io/`. If the
   game is served from a project subpath, the origin is still just the host.
2. **The game's fetch calls must include credentials:**
   ```js
   fetch("https://your-server.vercel.app/api/balance", { credentials: "include" })
   ```
   Without `credentials: "include"`, the browser won't send or store the cookie.
3. **Send players to login via a top-level navigation**, not fetch:
   ```js
   window.location.href = "https://your-server.vercel.app/api/auth/login";
   ```
4. The session cookie is set with `SameSite=None; Secure; HttpOnly` (required for
   cross-site) — this is already handled in the server code.

**After a test login, check the Vercel logs** for the line
`[auth/callback] session cookie set before redirect` — it prints the cookie
options (you should see `sameSite: "none", secure: true`) so you can confirm the
cookie was issued. Then call `/api/balance` from the game with
`credentials: "include"`: a clean `401 {"error":"not_logged_in"}` (with CORS
headers) means "cookie not sent"; a real balance means it worked.

> ⚠️ **Browser third-party-cookie blocking.** Safari (and Chrome with
> third-party cookies disabled) may block cross-site cookies **even when
> everything above is correct** — this is a browser policy, not a bug in the
> server. If logins work in a normal Chrome window but not in Safari/incognito,
> that's the cause. The robust fix is to stop relying on a third-party cookie:
> have the callback pass a short-lived token back to the game (in the redirect
> URL), have the game store it and send it as an `Authorization: Bearer <token>`
> header. Tell me if you hit this and I'll add that token mode.

---

## Running locally (optional)

```bash
npm install
cp .env.example .env.local   # then fill in the values
npm run dev                  # http://localhost:3000
```

For local testing set `GAME_ORIGIN=http://localhost:3000` and register a Whop
redirect URL of `http://localhost:3000/api/auth/callback`.
